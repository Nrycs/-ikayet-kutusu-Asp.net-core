﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WebApplication2.Models;

namespace WebApplication2.Controlers
{
    public class HomeController : Controller
    {
        private DataContext context;
        public HomeController(DataContext _context)
        {
            context = _context;
        }
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(string İsim, string Soyisim, string Numara, string Mail, string Mesaj)
        {
            Ticket ticket = new Ticket();
            ticket.Name = İsim;
            ticket.Surname = Soyisim;
            ticket.Number = Numara;
            ticket.Mail = Mail;
            ticket.Message = Mesaj;
            context.tickets.Add(ticket);
            int save = context.SaveChanges();
            if (save > 0)
            {
                TempData["response"] = "İşlem Başarılı.";
            }
            else
            {
                TempData["response"] = "İşlem Başarısız.";

            }
            return RedirectToAction("Index");
        }


        [HttpGet]
        public IActionResult Admin()
        {
            return View(context.tickets);
        }
        
        [HttpPost]
        public IActionResult Admin(int Id)
        {
            return View("/Home");
        }

        [HttpGet]
        public IActionResult Liste()
        {
            return View(context.tickets);
        }
        
        [HttpPost]
        public IActionResult Liste(int Id)
        {
            return View();
        }
        [HttpGet]
        public IActionResult Cevap(Guid id)
        {


            Answerr item = context.answers.FirstOrDefault(x => x.TicketID == id);

            return View(item);
        }
        
        [HttpPost]
        public IActionResult Cevap(int Id)
        {
            return View();
        }




    }
}
