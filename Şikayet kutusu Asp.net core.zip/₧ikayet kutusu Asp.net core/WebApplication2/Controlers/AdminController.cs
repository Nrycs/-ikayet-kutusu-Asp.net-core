﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Models;

namespace WebApplication2.Controlers
{
    public class AdminController : Controller
    {
        private DataContext context;

        public AdminController(DataContext _context)
        {
            context = _context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult List()
        {
            return View(context.tickets);
        }

        [HttpGet]
        public IActionResult Answer(Guid id)
        {
            Ticket item = context.tickets.FirstOrDefault(x => x.Id == id);
            return View(item);
        }
        [HttpPost]
        public IActionResult Answer(Guid Id , string İsim, string Soyisim, string Cevap,situation _islem)
        {
            Answerr answerr = new Answerr();
            answerr.TicketID =  Id;
            answerr.Surname = Soyisim;
            answerr.FirstName = İsim;
            answerr.answer = Cevap;
            answerr.CreatedDate = DateTime.Now;
            answerr.situation = _islem;
            context.answers.Add(answerr);
            context.SaveChanges();
            return RedirectToAction("List","Admin");
        }

        [HttpGet]
        public IActionResult Delete(Guid id)
        {
            Ticket ticket = context.tickets.Find(id);
            if (ticket != null)
            {
                context.tickets.Remove(ticket);
                context.SaveChanges();
            }
            return RedirectToAction("List", "Admin");
        }

    }
}
