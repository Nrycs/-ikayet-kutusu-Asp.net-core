﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
    public class Answerr
    {
        public Guid ID { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public DateTime DeletedDate { get; set; }
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string answer { get; set; }
        public Guid TicketID { get; set; }
        public situation situation { get; set; }
    }
}
